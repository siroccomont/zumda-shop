from decimal import Decimal
from client_buyers.models import Products
from django.conf import settings
from client_buyers.templatetags.custom_filters import get_sale_val


class Wish(object):
    def __init__(self, request):
        self.session = request.session
        wish = self.session.get(settings.WISH_SESSION_ID)
        if not wish:
            wish = self.session[settings.WISH_SESSION_ID] = {}
        self.wish = wish
        self.length = len(self.wish)

    def add_to_wish(self, product):
        product_id = str(product.id)
        if product.sale:
            price = get_sale_val(product.price, product.sale)
        else:
            price = product.price
        if product_id not in self.wish:
            self.wish[product_id] = {
                'product_name' : product.product_name,
                'price' : price
            }
        self.save()

    def save(self):
        self.session.modified = True

    def remove(self, product):
        product_id = str(product.id)

        if product_id in self.wish:
            del self.wish[product_id]
            self.save()

    def __iter__(self):
        product_ids = self.wish.keys()
        products = Products.objects.filter(id__in=product_ids)
        wish = self.wish.copy()
        for product in products:
            product_list = {
                'product' : product
            }
            yield product_list

    def clear(self):
        del self.session[settings.WISH_SESSION_ID]
        self.save()