from django.urls import path
from . import views

app_name = 'wish'

urlpatterns = [
    path('', views.wish_detail, name='wish_detail'),
    path('add/<int:pk>/', views.wish_add, name='wish_add'),
    path('remove/<int:pk>/', views.wish_remove,name='wish_remove'),
    ]