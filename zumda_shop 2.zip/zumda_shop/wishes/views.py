from django.shortcuts import render, get_object_or_404, redirect
from django.views.decorators.http import require_POST
from .wishes import Wish
from client_buyers.models import Products
from cart.forms import CartAddProductForm

@require_POST
def wish_add(request, pk):
    wish = Wish(request)
    product = get_object_or_404(Products, pk=pk)
    wish.add_to_wish(product=product)
    return redirect('wish:wish_detail')


@require_POST
def wish_remove(request, pk):
    wish = Wish(request)
    product = get_object_or_404(Products, pk=pk)
    wish.remove(product)
    return redirect('wish:wish_detail')


def wish_detail(request):
    wish = Wish(request)
    cart_product_form = CartAddProductForm
    return render(request, 'wishes-list.html', {'wish_data': wish, 'cart_product_form': cart_product_form})