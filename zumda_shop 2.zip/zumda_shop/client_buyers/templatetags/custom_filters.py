from django import template

register = template.Library()

@register.filter
def get_sale_val(price, sale):
    return int(price - ((price * int(sale)) / 100))