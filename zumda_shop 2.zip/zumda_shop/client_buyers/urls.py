from django.urls import path, include
from .views import *
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenVerifyView


urlpatterns = [
    path('', MainView.as_view(), name='main'),
    path('category/<int:pk>', DetailedView.as_view(), name='category'),
    path('category/post_category/<int:pk>/', PostDetailedView.as_view(), name='post_category'),
    path('product/<int:pk>', ProductView.as_view(), name='product'),
    path('search/', SearchView.as_view(), name='search'),
    path('wishes/', WishesList.as_view(), name='wishes'),
    path('api/product/list', ProductAPIList.as_view()),
    path('api/product/update/<int:pk>', ProductUpdateAPI.as_view()),
    path('api/product/delete/<int:pk>', ProductDeleteAPI.as_view()),
    path('api/token/', TokenObtainPairView.as_view()),
    path('api/token/refresh/', TokenRefreshView.as_view()),
    path('api/token/verify/', TokenVerifyView.as_view()),
    path('login/', LoginUser.as_view(), name='login'),
    path('logout/', logout_user, name='logout'),
    path('signupuser/', SignUpUser.as_view(), name='signup'),

]