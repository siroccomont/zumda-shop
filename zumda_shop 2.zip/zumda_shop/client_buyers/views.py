from django.shortcuts import render, redirect
from django.views.generic import TemplateView, ListView, DetailView, CreateView
from cart.forms import CartAddProductForm
from .models import *
from .serializers import *
from rest_framework.generics import (
    ListCreateAPIView,
    RetrieveDestroyAPIView,
    RetrieveUpdateAPIView
)
# from rest_framework import mixins, viewsets, response
from rest_framework.decorators import action
from rest_framework.permissions import (
    IsAuthenticatedOrReadOnly,
    IsAdminUser,
    IsAuthenticated
)
from django.urls import reverse_lazy
from .forms import *
from django.contrib.auth import logout
from django.contrib.auth.views import LoginView
from cart.cart import Cart
from wishes.wishes import Wish
from django.db.models import Q
from django.core.paginator import Paginator


class MainView(ListView):
    template_name = 'index.html'
    model = Category

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        products = Products.objects.all()
        context["products"] = products
        cats = Category.objects.all()
        context['cats'] = cats
        cart = Cart(request=self.request)
        context['len_cart'] = len(cart.cart)
        context['len_wish'] = Wish(request=self.request).length
        return context


class DetailedView(DetailView):
    template_name = 'electronic.html'
    model = Products

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cat_pk = self.kwargs.get('pk')
        context['cat_name'] = Category.objects.get(pk=cat_pk)
        context['cats'] = PostCategory.objects.filter(category_id=cat_pk)
        context['categories'] = Category.objects.all()
        # Under main function
        products = Products.objects.filter(category_id=cat_pk)
        sort = self.request.GET.get('sort')
        if sort == 'high':
            products = products.order_by('-rate')
        elif sort == 'cheap':
            products = products.order_by('price')
        elif sort == 'expensive':
            products = products.order_by('-price')
        elif sort == 'fast':
            products = products.order_by('delivery')
        paginator = Paginator(products, 6)
        page_number = self.request.GET.get("page")
        page_obj = paginator.get_page(page_number)
        context['page_obj'] = page_obj
        # Filter request
        return context


class PostDetailedView(DetailView):
    template_name = 'electronic.html'
    model = PostCategory

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post_pk = self.kwargs.get('pk')
        post_cat_name = PostCategory.objects.get(pk=post_pk)
        context['category'] = Category.objects.get(category_name=post_cat_name.category_id)
        context['cat'] = PostCategory.objects.filter(category_id=post_cat_name.category_id)
        context['cats'] = Category.objects.all()
        context['cat_name'] = post_cat_name
        products = Products.objects.filter(post_cat_id=post_pk)
        sort = self.request.GET.get('sort')
        if sort == 'high':
            products = products.order_by('-rate')
        elif sort == 'cheap':
            products = products.order_by('price')
        elif sort == 'expensive':
            products = products.order_by('-price')
        elif sort == 'fast':
            products = products.order_by('delivery')
        paginator = Paginator(products, 1)
        page_number = self.request.GET.get("page")
        page_obj = paginator.get_page(page_number)
        context['page_obj'] = page_obj
        context['products'] = products
        return context


class ProductView(DetailView):
    template_name = 'fashion.html'
    model = Products

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        p_pk = self.kwargs.get('pk')
        product = Products.objects.get(pk=p_pk)
        context['product'] = product
        context['images'] = ProductPicture.objects.filter(product_id=p_pk)
        context['post_similar'] = Products.objects.filter(post_cat_id = product.post_cat_id, category_id = product.category_id)
        available_colors = [(color, color) for color in product.color]
        available_screen = [(screen, screen) for screen in product.screen_size]
        available_memory = [(memory, memory) for memory in product.memory_size]
        available_clothing = [(clothes, clothes) for clothes in product.clothing_size]
        available_shoe = [(shoe, shoe) for shoe in product.shoe_size]
        cart_product_form = CartAddProductForm(available_colors=available_colors, available_screen=available_screen, available_memory=available_memory, available_clothing=available_clothing, available_shoe_size=available_shoe)
        context['cart_product_form'] = cart_product_form

        products = Products.objects.filter(post_cat_id=p_pk)
        paginator = Paginator(products, 1)
        page_number = self.request.GET.get("page")
        page_obj = paginator.get_page(page_number)
        context['page_obj'] = page_obj
        context['products'] = products
        return context


class SearchView(ListView):
    template_name = 'search.html'
    model = Products
    paginate_by = 3
    context_object_name = 'products'

    def get(self, request, *args, **kwargs):
        self.search = Products.objects.filter(Q(product_name__contains=request.GET['search']) | Q(description__contains=request.GET['search']) | Q(color__contains=request.GET['search']))
        self.srch = request.GET['search']
        return super().get(request, *args, **kwargs)

    def get_queryset(self):
        return self.search

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['srch'] = self.srch
        return context


class ProductAPIList(ListCreateAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticatedOrReadOnly,]


class ProductUpdateAPI(RetrieveUpdateAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAdminUser,]


class ProductDeleteAPI(RetrieveDestroyAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAdminUser,]


class WishesList(TemplateView):
    template_name = 'wishes-list.html'


class SignUpUser(CreateView):
    form_class = UserForm
    template_name = 'signup.html'
    success_url = reverse_lazy('login')


class LoginUser(LoginView):
    form_class = UserLoginForm
    template_name = 'login.html'

    def get_success_url(self):
        return reverse_lazy('main')


def logout_user(request):
    logout(request)
    return redirect('main')




# class ProductAPI(viewsets.ModelViewSet):
#     queryset = Products.objects.all()
#     serializer_class = ProductSerializer
#
#     @action(methods=['get', ], detail=True)
#     def category(self, request, pk=None):
#         category = Category.objects.get(pk=pk)
#         return response.Response({'category': [category.category_name]})
#
#     @action(methods=['get', ], detail=False)
#     def categories(self, request):
#         categories = Category.objects.all()
#         return response.Response({'categories': [c.category_name for c in categories]})
#
#     @action(methods=['get', ], detail=True)
#     def post_category(self, request, pk=None):
#         post_cat = PostCategory.objects.get(pk=pk)
#         return response.Response({'post_cat': [post_cat.post_cat_name]})
#
#     @action(methods=['get', ], detail=False)
#     def post_categories(self, request):
#         post_cats = PostCategory.objects.all()
#         return response.Response({'post_cat': [p.post_cat_name for p in post_cats]})
#
#     @action(methods=['get', ], detail=True)
#     def seller(self, request, pk=None):
#         seller = Seller.objects.get(pk=pk)
#         return response.Response({'Seller' : [f'{seller.company_label}, {seller.company_email_address}']})
#
#     @action(methods=['get', ], detail=False)
#     def sellers(self, request):
#         sellers = Seller.objects.all()
#         return response.Response({'Seller': [s.company_label for s in sellers]})
#
#     @action(methods=['get',], detail=True)
#     def pictures(self, request, pk=None):
#         pictures = ProductPicture.objects.filter(pk=pk)
#         return response.Response({'Pictures' : [p.pic for p in pictures]})