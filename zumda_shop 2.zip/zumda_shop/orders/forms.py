from django import forms
from .models import Order, region


class OrderCreateForm(forms.ModelForm):
    city = forms.ChoiceField(choices=region,
                                    widget=forms.Select(attrs={'class': 'form-control'}))
    class Meta:
        model = Order
        fields = ['fullname', 'email', 'address','city']
        widgets = {
            'fullname' : forms.TextInput(attrs={
                'class' : 'form-control',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
            }),
            'address': forms.TextInput(attrs={
                'class': 'form-control',
            }),
        }

