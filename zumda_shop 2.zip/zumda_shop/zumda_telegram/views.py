from settings import dp, types, bot, Dispatcher
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from keyboards.menu import menu_ru, cat_menu, post_cat_menu
import requests
import sqlite3 as sql


class UserState(StatesGroup):
    title = State()
    about = State()
    id = State()


async def start(message: types.Message):
    await bot.send_message(message.from_user.id, 'Добро пожаловать в 1Zumda-Shop ', reply_markup=menu_ru)


async def cat_chose(message:types.Message):
    await bot.send_message(message.from_user.id, 'Категория:', reply_markup=cat_menu)


async def post_cat_chose(message:types.Message):
    await bot.send_message(message.from_user.id, 'Под Категория:', reply_markup=post_cat_menu)

async def ru_read(message: types.Message):
    posts = requests.get('http://127.0.0.1:8000/api/product/list').json()
    for post in posts:
        text = f'''
        Id:  {post['id']}\n
        Product name:  {post['product_name']}\n
        Description:  {post['description']}
        Color:  {post['color']}\n
        Price:  {post['price']}\n
        '''
        await bot.send_message(message.from_user.id, text, reply_markup=menu_ru)


async def ru_create(message: types.Message):
    await UserState.title.set()
    await bot.send_message(message.from_user.id, 'Введите название поста')


async def ru_title_get(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['title'] = message.text
    await UserState.next()
    await bot.send_message(message.from_user.id, 'Введите описание поста')


async def ru_about_get(message: types.Message, state: FSMContext):
    post_info = {}
    async with state.proxy() as data:
        data['about'] = message.text
    post_info['title'] = data['title']
    post_info['about'] = data['about']
    post = requests.post('http://127.0.0.1:8000/api/post/', data=post_info)
    await bot.send_message(message.from_user.id, f"Данные приняты\n\n"
                                                 f"{post.json()['title']}\n"
                                                 f"{post.json()['about']}")
    await state.finish()


async def ru_delete(message: types.CallbackQuery):
    posts = requests.get('http://127.0.0.1:8000/api/post/').json()
    for post in posts:
        text = f'''Id:  {post['id']}\nTitle:  {post['title']}\nAbout:  {post['about']}'''
        await bot.send_message(message.from_user.id, text, reply_markup=InlineKeyboardMarkup().add
        (InlineKeyboardButton(f"Удалить {post['title']}", callback_data=f"del {post['title']}")))
        await bot.send_message(message.from_user.id, 'Пост удален')


def register_handlers_views(dp: Dispatcher):
    dp.register_message_handler(start, commands=['start'])
    dp.register_message_handler(start, Text(contains='Назад'))
    dp.register_message_handler(cat_chose, Text(contains='🗄'))
    dp.register_message_handler(cat_chose, Text(contains='⚡'))
    dp.register_message_handler(ru_create, Text(contains='Создать'), state=None)
    dp.register_message_handler(ru_title_get, state=UserState.title)
    dp.register_message_handler(ru_about_get, state=UserState.about)
    dp.register_message_handler(ru_delete, Text(contains='Удалить'))