from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


back_ru = KeyboardButton('Назад')


categories = KeyboardButton('🗄Категории')
orders = KeyboardButton('🛒Заказы')
wishes = KeyboardButton('📥Избранные')
search = KeyboardButton('🔍Искать по имени продукта')
menu_ru = ReplyKeyboardMarkup(resize_keyboard=True)

menu_ru.row(categories).row(orders, wishes).row(search)

# Categories list

electronics = KeyboardButton('⚡️Электроника')
medicine = KeyboardButton('💊Здаровье')
cat_menu = ReplyKeyboardMarkup(resize_keyboard=True)

cat_menu.row(electronics, medicine).row(back_ru)


smartphones = KeyboardButton('📱Смартфоны')
headphones = KeyboardButton('🎧Наушники')
laptops = KeyboardButton('💻Ноутбуки')
post_cat_menu = ReplyKeyboardMarkup(resize_keyboard=True)

post_cat_menu.row(smartphones, headphones).row(laptops).row(back_ru)