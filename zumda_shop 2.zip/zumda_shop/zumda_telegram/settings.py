from aiogram import Bot, types, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage

storage = MemoryStorage()

bot = Bot(token='6253267597:AAFjz2WCxW0qy3SA6tbRucYtb_dho3pi79c')
dp = Dispatcher(bot, storage=storage)