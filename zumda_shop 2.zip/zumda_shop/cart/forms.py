from django import forms
from client_buyers.models import colors, clothing_sizes, shoe_sizes, memory_sizes, screen_sizes

PRODUCT_QUANTITY_CHOICES = [(i, str(i)) for i in range(1, 21)]

CHOOSE_COLORS = [c for c in colors]
CLOTHING_SIZE = [cl for cl in clothing_sizes]
SHOE_SIZE = [sh for sh in shoe_sizes]
MEMORY_SIZE = [m for m in memory_sizes]
SCREEN_SIZE = [s for s in screen_sizes]



class CartAddProductForm(forms.Form):

    quantity = forms.TypedChoiceField(
                                choices=PRODUCT_QUANTITY_CHOICES,
                                coerce=int,
                                widget=forms.Select(attrs={'class': 'form-control'})

    )
    override = forms.BooleanField(required=False,
                                    initial=False,
                                    widget=forms.HiddenInput(attrs={'class': 'form-control'}))

    color = forms.TypedChoiceField(
            choices=CHOOSE_COLORS,
            coerce=str,
            widget=forms.Select(attrs={'class' : 'form-control'})
    )
    screen = forms.TypedChoiceField(
        choices = SCREEN_SIZE,
        coerce = str,
        widget = forms.Select(attrs={'class' : 'form-control'})
    )
    memory = forms.TypedChoiceField(
        choices=MEMORY_SIZE,
        coerce=str,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    clothes = forms.TypedChoiceField(
        choices=CLOTHING_SIZE,
        coerce=str,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    shoe = forms.TypedChoiceField(
        choices=SHOE_SIZE,
        coerce=int,
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    def __init__(self, *args, **kwargs):
        available_colors = kwargs.pop('available_colors', None)
        available_screen = kwargs.pop('available_screen', None)
        available_memory = kwargs.pop('available_memory', None)
        available_clothing = kwargs.pop('available_clothing', None)
        available_shoe_size = kwargs.pop('available_shoe_size', None)
        super().__init__(*args, **kwargs)
        if available_colors:
            self.fields['color'].required = True
            self.fields['color'].choices = available_colors
        else:
            self.fields['color'].required = False
            self.fields['color'].widget = forms.HiddenInput()

        if available_screen:
            self.fields['screen'].required = True
            self.fields['screen'].choices = available_screen
        else:
            self.fields['screen'].required = False
            self.fields['screen'].widget = forms.HiddenInput()

        if available_memory:
            self.fields['memory'].required = True
            self.fields['memory'].choices = available_memory
        else:
            self.fields['memory'].required = False
            self.fields['memory'].widget = forms.HiddenInput()

        if available_clothing:
            self.fields['clothes'].required = True
            self.fields['clothes'].choices = available_clothing
        else:
            self.fields['clothes'].required = False
            self.fields['clothes'].widget = forms.HiddenInput()

        if available_shoe_size:
            self.fields['shoe'].required = True
            self.fields['shoe'].choices = available_shoe_size
        else:
            self.fields['shoe'].required = False
            self.fields['shoe'].widget = forms.HiddenInput()