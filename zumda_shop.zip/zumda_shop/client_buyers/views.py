from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from .models import *
from .serializers import *
from rest_framework.generics import *
from rest_framework import mixins, viewsets, response
from rest_framework.decorators import action

class MainView(ListView):
    template_name = 'index.html'
    model = Category

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["products"] = Products.objects.all()
        cats = Category.objects.all()
        context['cats'] = cats
        return context


class DetailedView(DetailView):
    template_name = 'electronic.html'
    model = Category

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cat_pk = self.kwargs.get('pk')
        context['cats'] = PostCategory.objects.filter(category_id=cat_pk)
        context['products'] = Products.objects.filter(category_id=cat_pk)

        return context

class ProductView(DetailView):
    template_name = 'fashion.html'
    model = Products

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        p_pk = self.kwargs.get('pk')
        context['product'] = Products.objects.get(pk=p_pk)
        context['images'] = ProductPicture.objects.filter(product_id=p_pk)
        return context



class ProductAPI(viewsets.ModelViewSet):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer

    @action(methods=['get', ], detail=True)
    def category(self, request, pk=None):
        category = Category.objects.get(pk=pk)
        return response.Response({'category': [category.category_name]})

    @action(methods=['get', ], detail=False)
    def categories(self, request):
        categories = Category.objects.all()
        return response.Response({'categories': [c.category_name for c in categories]})

    @action(methods=['get', ], detail=True)
    def post_category(self, request, pk=None):
        post_cat = PostCategory.objects.get(pk=pk)
        return response.Response({'post_cat': [post_cat.post_cat_name]})

    @action(methods=['get', ], detail=False)
    def post_categories(self, request):
        post_cats = PostCategory.objects.all()
        return response.Response({'post_cat': [p.post_cat_name for p in post_cats]})

    @action(methods=['get', ], detail=True)
    def seller(self, request, pk=None):
        seller = Seller.objects.get(pk=pk)
        return response.Response({'Seller' : [f'{seller.company_label}, {seller.company_email_address}']})

    @action(methods=['get', ], detail=False)
    def sellers(self, request):
        sellers = Seller.objects.all()
        return response.Response({'Seller': [s.company_label for s in sellers]})

    @action(methods=['get',], detail=True)
    def pictures(self, request, pk=None):
        pictures = ProductPicture.objects.filter(pk=pk)
        return response.Response({'Pictures' : [p.pic for p in pictures]})