from rest_framework import serializers
from .models import *
from multiselectfield import MultiSelectField


class ProductSerializer(serializers.ModelSerializer):
    clothing_size = serializers.MultipleChoiceField(choices=clothing_sizes)
    color = serializers.MultipleChoiceField(choices=colors)
    screen_size = serializers.MultipleChoiceField(choices=screen_sizes)
    memory_size = serializers.MultipleChoiceField(choices=memory_sizes)
    shoe_size = serializers.MultipleChoiceField(choices=shoe_sizes)

    class Meta:
        model = Products
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class PostCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = PostCategory
        fields = '__all__'

class SellerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Seller
        fields = '__all__'

class BrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brands
        fields = '__all__'

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Orders
        fields = '__all__'

class ProductPictureSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductPicture
        fields = '__all__'

class CombinedSerializer(serializers.Serializer):
    products = ProductSerializer()
    product_pic = ProductPictureSerializer()