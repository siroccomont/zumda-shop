from django.contrib import admin
from .models import *

admin.site.register(Category)
admin.site.register(PostCategory)
admin.site.register(Seller)
admin.site.register(Brands)
admin.site.register(Products)
admin.site.register(ProductPicture)
admin.site.register(Orders)
