from django.urls import path, include
from .views import *
from rest_framework import routers

router = routers.SimpleRouter()
router.register(r'product', ProductAPI)

print(router.urls)

urlpatterns = [
    path('', MainView.as_view(), name='main'),
    path('category/<int:pk>', DetailedView.as_view(), name='detailed'),
    path('product/<int:pk>', ProductView.as_view(), name='product'),
    path('api/v1/', include(router.urls))

]