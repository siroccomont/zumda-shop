from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from .models import *
from .serializers import *
from rest_framework.generics import *


class MainView(ListView):
    template_name = 'index.html'
    model = Category

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["products"] = Products.objects.all()
        cats = Category.objects.all()
        context['cats'] = cats
        return context


class DetailedView(DetailView):
    template_name = 'electronic.html'
    model = Category

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cat_pk = self.kwargs.get('pk')
        context['cats'] = PostCategory.objects.filter(category_id=cat_pk)
        context['products'] = Products.objects.filter(category_id=cat_pk)

        return context

class ProductView(DetailView):
    template_name = 'fashion.html'
    model = Products

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        p_pk = self.kwargs.get('pk')
        context['product'] = Products.objects.get(pk=p_pk)
        context['images'] = ProductPicture.objects.filter(product_id=p_pk)
        return context

class ProductListAPI(ListAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer

class ProductCreateAPIView(CreateAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer

class ProductUpdateAPIView(RetrieveUpdateAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer

class ProductDeleteAPIView(RetrieveDestroyAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer

class ProductPictureCreateAPIView(CreateAPIView):
    queryset = ProductPicture.objects.all()
    serializer_class =  ProductPictureSerializer
