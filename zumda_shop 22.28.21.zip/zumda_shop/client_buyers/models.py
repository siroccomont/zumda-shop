from django.db import models
from multiselectfield import MultiSelectField


class Category(models.Model):
    category_name = models.CharField('Category name', max_length=155)
    cat_pic = models.ImageField(upload_to='category_pic')

    def __str__(self):
        return self.category_name


class PostCategory(models.Model):
    post_cat_name = models.CharField('Post Category Name', max_length=155)
    category_id = models.ForeignKey(Category, related_name='cat_post_cat', on_delete=models.CASCADE)
    post_cat_pic = models.ImageField(upload_to='post_category_pic', default=False)

    def __str__(self):
        return self.post_cat_name


class Seller(models.Model):
    company_label = models.CharField('Company label', max_length=255)
    company_inn = models.CharField('Company Invoice number', max_length=45)
    company_email_address = models.CharField('Company email address', max_length=155)
    company_address = models.CharField('Company local address', max_length=255)

    def __str__(self):
        return self.company_label


class Brands(models.Model):
    brand_name = models.CharField('Brand name', max_length=255)
    brand_post_category = models.ForeignKey(PostCategory, on_delete=models.CASCADE)

    def __str__(self):
        return self.brand_name


delivery_duration = [
    ('None', 'None'),
    ('1 day free','1 day free'),
    ('2 day free','2 day free'),
    ('3 day free','3 day free'),
    ('4 day free','4 day free'),
    ('5 day free','5 day free'),
]

colors = [
    ('None', 'None'),
    ('White','White'),
    ('Black','Black'),
    ('Green','Green'),
    ('Red','Red'),
    ('Orange','Orange'),
]

clothing_sizes = [
    ('None', 'None'),
    ('XS', 'XS'),
    ('S','S'),
    ('M','M'),
    ('L','L'),
    ('XL','XL'),
    ('XXL','XXL'),
    ('XXXL', 'XXXL'),
]

screen_sizes = [
    ('None', 'None'),
    ('12X','12X'),
    ('24X','24X'),
    ('48X','48X'),
    ('96X','96X'),
    ('192X','192X'),
]

memory_sizes = [
    ('None', 'None'),
    ('16GB', '16GB'),
    ('32GB','32GB'),
    ('64GB','64GB'),
    ('128GB','128GB'),
    ('256GB','256GB'),
    ('512GB','512GB'),
]

shoe_sizes = [
    ('None', 'None'),
    ('32','32'),
    ('33','33'),
    ('34','34'),
    ('35','35'),
    ('36','36'),
    ('37', '37'),
    ('38', '38'),
    ('39', '39'),
    ('40', '40'),
    ('41', '41'),
    ('42', '42'),
    ('43', '43'),
    ('44', '44'),
    ('45', '45'),
]


class Products(models.Model):
    category_id = models.ForeignKey(Category, related_name='product_cat', on_delete=models.CASCADE)
    post_cat_id = models.ForeignKey(PostCategory, related_name='product_post_cat', on_delete=models.CASCADE)
    product_name = models.CharField('Product_name', max_length=255)
    product_seller_id = models.ForeignKey(Seller, on_delete=models.CASCADE)
    delivery = models.CharField('Delivery duration', max_length=155, choices=delivery_duration, default=delivery_duration[0])
    quantity_in_stock = models.IntegerField('Quantity in cell', default=0)
    rate = models.IntegerField('Product Rate', blank=True, null=True, default=1)
    price = models.IntegerField('Price')
    description = models.TextField('Description', blank=True, null=True, default=False)
    brand_id = models.ForeignKey(Brands, on_delete=models.CASCADE, blank=True, null=True)
    color = MultiSelectField('Color', choices=colors, blank=True, null=True, default=colors[0], max_length=50)
    clothing_size = MultiSelectField('Clothing size', choices=clothing_sizes, blank=True, null=True, default=clothing_sizes[0], max_length=50)
    screen_size = MultiSelectField('Screen size', choices=screen_sizes, blank=True, null=True, default=screen_sizes[0], max_length=50)
    memory_size = MultiSelectField('Memory size', choices=memory_sizes, blank=True, null=True, default=memory_sizes[0], max_length=50)
    shoe_size = MultiSelectField('Shoe size', choices=shoe_sizes, blank=True, null=True, default=shoe_sizes[0], max_length=50)
    added_to_cell = models.DateTimeField('Added date', auto_now_add=True)
    updated = models.DateTimeField('Updated date', auto_now=True)

    def __str__(self):
        return self.product_name


class ProductPicture(models.Model):
    product_id = models.ForeignKey(Products, related_name='p_photo', on_delete=models.CASCADE)
    pic = models.ImageField(upload_to='product_photo')

    def __str__(self):
        return f'Photo :{self.pk}, Porduct : {self.product_id.product_name}'


class Orders(models.Model):
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField('Status of Order', max_length=15)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    delivered_date = models.DateTimeField()
    updated = models.DateTimeField()
    user = models.CharField('User', max_length=139)

    def __str__(self):
        return f'Order : {self.pk}, Product : {self.product.product_name}'

    