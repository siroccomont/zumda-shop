from django.urls import path, include
from .views import *

urlpatterns = [
    path('', MainView.as_view(), name='main'),
    path('category/<int:pk>', DetailedView.as_view(), name='detailed'),
    path('product/<int:pk>', ProductView.as_view(), name='product'),
    path('api/product/list', ProductListAPI.as_view()),
    path('api/product/create', ProductCreateAPIView.as_view()),
    path('api/product/delete/<int:pk>', ProductDeleteAPIView.as_view()),
    path('api/product/update/<int:pk>', ProductUpdateAPIView.as_view()),
    path('api/product-picture/create', ProductPictureCreateAPIView.as_view()),

]